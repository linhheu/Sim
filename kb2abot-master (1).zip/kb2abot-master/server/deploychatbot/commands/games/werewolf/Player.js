class Player {
	constructor({
		id,
		index
	} = {}) {
		this.id = id;
		this.index = index;
	}
}

export default Player;
