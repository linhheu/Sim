import FortuneTeller from "./FortuneTeller.js";
import Guard from "./Guard.js";
import Werewolf from "./Werewolf.js";
import Villager from "./Villager.js";
import Hunter from "./Hunter.js";

export {
	FortuneTeller,
	Guard,
	Werewolf,
	Villager,
	Hunter
};
