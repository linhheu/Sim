import TicTacToe from "./TicTacToe.js";
import MaSoi from "./masoi";
// import Werewolf from "./werewolf";

export {
	TicTacToe,
	MaSoi
	// Werewolf
};
